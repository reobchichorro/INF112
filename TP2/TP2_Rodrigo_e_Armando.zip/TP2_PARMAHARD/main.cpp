#include <iostream>
#include <stdio.h>

#include "terminal.h"

int main(){
    init();
    return 0;
}
